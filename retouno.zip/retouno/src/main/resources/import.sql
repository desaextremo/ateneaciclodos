insert into user(id,user_name,user_email,user_password) values(1,'NAPOLEON BONAPARTE','nbonaparte@gmail.com','nbonaparte123');
insert into user(id,user_name,user_email,user_password) values(2,'ADOLFO HITLER','ahitler@gmail.com','hitler123');
insert into user(id,user_name,user_email,user_password) values(3,'JOSEPH STALIN','jstalin@gmail.com','stalin123');
insert into user(id,user_name,user_email,user_password) values(4,'LEONOR DE AQUITANIA','laquitania@gmail.com','leonora123');
insert into user(id,user_name,user_email,user_password) values(5,'MARIA ESTUARDO','mestuardo@gmail.com','mariae123');