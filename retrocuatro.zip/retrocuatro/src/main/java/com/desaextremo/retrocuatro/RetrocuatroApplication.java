package com.desaextremo.retrocuatro;

import com.desaextremo.retrocuatro.repository.crud.GadgetCrudRepository;
import com.desaextremo.retrocuatro.repository.crud.OrderCrudRepository;
import com.desaextremo.retrocuatro.repository.crud.UserCrudRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.beans.factory.annotation.Autowired;

@SpringBootApplication
public class RetrocuatroApplication implements CommandLineRunner{
	@Autowired
	private GadgetCrudRepository gadgetCrudRepository;
	@Autowired
	private UserCrudRepository userCrudRepository;

	@Autowired
	private OrderCrudRepository orderCrudRepository;
	public static void main(String[] args) {
		SpringApplication.run(RetrocuatroApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		gadgetCrudRepository.deleteAll();
		userCrudRepository.deleteAll();
		orderCrudRepository.deleteAll();
	}
}
