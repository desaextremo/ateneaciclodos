package com.desaextremo.retrocuatro.repository.crud;

import com.desaextremo.retrocuatro.model.Gadget;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

/**
 *
 * @author desaextremo
 */
public interface GadgetCrudRepository extends MongoRepository<Gadget, Integer> {
    public List<Gadget> findByPriceLessThanEqual(double precio);

    public List<Gadget> findByCategory(String categoria);

    @Query("{'name':{'$regex':'?0','$options':'i'}}")
    public List<Gadget> findByNameLike(String name);
}
